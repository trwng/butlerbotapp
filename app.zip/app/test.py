import tflite_runtime.interpreter as tflite
import platform

EDGETPU_SHARED_LIB = {
    'Linux': 'libedgetpu.so.1',
    'Darwin': 'libedgetpu.1.dylib',
    'Windows': 'edgetpu.dll'
}[platform.system()]

try:
    delegate = tflite.load_delegate(EDGETPU_SHARED_LIB)
    print("Edge TPU delegate loaded successfully!")
except Exception as e:
    print("Failed to load Edge TPU delegate:", e)